# expense-manager-12

+ Track expenses using Google Charts API, image receipts uploads etc. 
+ Copy HTML tables, generate csv reports and many more features.
+ The database contains only old records that are visible only in 'ALL EXPENSES' link.
+ Add new entries and check dynamic update of graphs in each page.

# Dummy Credentials

`Admin-User: Super`

`Password: 1234`
